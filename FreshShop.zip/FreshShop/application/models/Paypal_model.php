<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Paypal_model extends CI_Model{
   
    //insert transaction data
    public function insertTransaction($data = array()){
        //$insert = $this->db->insert('payments',$data);
        $insert = $this->db->where('unq_id',$data['unq_id'])->update('payments',$data);
        return $insert?true:false;
    }
}