<?php
class Home_model extends CI_Model
{
	public function getCategories(){
		$data= $this->db->select("*")->from("categories")->get()->result();
		if(!empty($data)){
			return $data;
		}else{
			return false;
		}
	}

	public function getCategoryByID($id){
		$data= $this->db->select("*")->from("categories")->where('id',$id)->get()->row();
		if(!empty($data)){
			return $data;
		}else{
			return false;
		}
	}
	public function getCategoryProducts($id){
		$data= $this->db->select("*")->from("products")->where('category_id',$id)->order_by('title','desc')->get()->result();
		if(!empty($data)){
			return $data;
		}else{
			return false;
		}
	}

	public function getProductById($id){
		$data= $this->db->select("p.*, p.id as product_id, p.image as pimage,c.*, c.id as category_id,c.image as cimage,p.description as pdescription,c.description as cdescription")->from("products p")->join('categories c','c.id = p.category_id')->where('p.id',$id)->get()->row();
		//$data= $this->db->select("*")->from("products")->where('category_id',$id)->order_by('title','desc')->get()->result();
		if(!empty($data)){
			return $data;
		}else{
			return false;
		}
	}

	public function unqIdExist($unqID){
		$data= $this->db->select("*")->from("my_cart")->where('unq_id',$unqID)->get()->row();
		if(!empty($data)){
			return $data;
		}else{
			return false;
		}
	}

	public function getQuoteByProduct($unqID,$pid){
		$data= $this->db->select("*")->from("my_cart")->where('unq_id',$unqID)->where('product_id',$pid)->get()->row();
		if(!empty($data)){
			return $data;
		}else{
			return false;
		}
	}

	public function getCarts($uid){
		$data= $this->db->select("m.*,m.id as cart_id,p.*, p.id as product_id,p.image as pimage, c.*, c.id as category_id,c.image as cimage")->from("my_cart m")->join("products p",'p.id = m.product_id')->join('categories c','c.id = p.category_id')->where('m.unq_id',$uid)->get()->result();
		if(!empty($data)){
			return $data;
		}else{
			return false;
		}
	}

	public function getGrandTotal($unq_id){
		$data=$this->db->select("SUM(total_price) as tp")->from("my_cart")->where("unq_id",$unq_id)->get()->row();
		if(!empty($data)){
			return $data;
		}else{
			return false;
		}
	}

	public function countCart($unq_id){
		$data=$this->db->select("COUNT(id) as tCart")->from("my_cart")->where("unq_id",$unq_id)->get()->row();
		if(!empty($data)){
			return $data;
		}else{
			return false;
		}
	}

	public function removeProduct($id){
		$data= $this->db->where('id',$id)->delete('my_cart');
		if($data){
			return true;
		}else{
			return false;
		}
	}
}