<?php
defined('BASEPATH') or exit('No direct script access allowed');

	class Home extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->helper(array('url','form'));
			$this
            ->load
            ->library('form_validation');
	        $this
	            ->load
	            ->library('session');
	        $this
	            ->load
	            ->library('paypal_lib');
	        $this
	            ->load
	            ->model('Home_model');
	        $this
	            ->load
	            ->database();
	        $this
	            ->load
	            ->library('email');
		}

		public function index(){
			$data['catgories']= $this->Home_model->getCategories();
			$this->load->view('header');
			$this->load->view('slider');
			$this->load->view('index',$data);
			$this->load->view('footer');
		}

		public function shop(){
			$data['catgories']= $this->Home_model->getCategories();
			$this->load->view('header');
			$this->load->view('index',$data);
			$this->load->view('footer');
		}

		public function gallery(){
			$this->load->view('header');
			$this->load->view('gallery');
			$this->load->view('footer');
		}

		public function category($id){
			$data['category']= $this->Home_model->getCategoryByID($id);
			$data['products']= $this->Home_model->getCategoryProducts($id);
			$this->load->view('header');
			$this->load->view('products',$data);
			$this->load->view('footer');
		}

		public function view($id){
			$data['product']= $this->Home_model->getProductById($id);
			$this->load->view('header');
			$this->load->view('product_detail',$data);
			$this->load->view('footer');
		}

		public function addToCart(){
			$pid = $this->input->post('pid');
			$qty = $this->input->post('qty');

			$data['status']=0;
			$data['msg']="";
			if(!isset($_SESSION['unq_id'])){
				$unq_id = uniqid();
				$uExist= $this->Home_model->unqIdExist($unq_id);
				if($uExist != false){
					addToCart($pid);
				}
				$sessionData = array(
	                'unq_id' => $unq_id
	            );
	            $this
	                ->session
	                ->set_userdata($sessionData);
	            $product= $this->Home_model->getProductById($pid);
	            if($product == false){
	            	$data['msg']="Product doesn't exist.";	
	            }else{
	            	$qty = ($qty != null ? $qty : 1);
	            	$price = $product->price;
	            	$total	=	$qty*$price;
	            	$saveData= array(
	            		'unq_id' 		=>	$unq_id,
	            		'product_id'  	=>  $pid,
	            		'qty' 			=>  $qty,
	            		'price'			=>	$price,
	            		'total_price'	=>	$total
	            	);
	            	$inserted = $this->db->insert('my_cart',$saveData);
	            	if($inserted){
	            		$data['status']=1;
	            		$data['msg']="Data Saved.";
	            	}else{
	            		$data['msg']="Not Saved.";
	            	}
	            }
			}else{
				$product= $this->Home_model->getProductById($pid);
	            if($product == false){
	            	$data['msg']="Product doesn't exist.";	
	            }else{
	            	$unq_id = $this->session->userdata('unq_id');
	            	$qty = ($qty == null || $qty == 0 ? 1 : $qty);
		            	$price = $product->price;
		            	$total	=	$qty*$price;
		            	$saveData= array(
		            		'unq_id' 		=>	$unq_id,
		            		'product_id'  	=>  $pid,
		            		'qty' 			=>  $qty,
		            		'price'			=>	$price,
		            		'total_price'	=>	$total
		            	);
	            	$getCart = $this->Home_model->getQuoteByProduct($unq_id,$pid);
	            	if($getCart == false){	
	            		$inserted = $this->db->insert('my_cart',$saveData);
		            	if($inserted){
		            		$data['status']=1;
		            		$data['msg']="Data Saved.";
		            	}else{
		            		$data['msg']="Not Saved.";
		            	}
	            	}else{
	            		$updated = $this->db->where('unq_id',$unq_id)->where('product_id',$pid)->update('my_cart',$saveData);
		            	if($updated){
		            		$data['status']=1;
		            		$data['msg']="Data Saved.";
		            	}else{
		            		$data['msg']="Not Saved.";
		            	}
	            	}
	            	
			}
		}
		echo json_encode($data);
	}

	public function myCart(){
			$data['carts']="";
			if(isset($_SESSION['unq_id'])){
				$unq_id = $this->session->userdata('unq_id');
				$data['carts']= $this->Home_model->getCarts($unq_id);
				$data['total']= $this->Home_model->getGrandTotal($unq_id);
				
			}
			
			$this->load->view('header');
			$this->load->view('cart',$data);
			$this->load->view('footer');
	}

	public function clearCart(){
		if(isset($_SESSION['unq_id'])){
				$unq_id = $this->session->userdata('unq_id');
				$deleted= $this->db->where('unq_id',$unq_id)->delete('my_cart');
				if($deleted){
					 $this
			            ->session
			            ->sess_destroy();
		        	
		        }
			}
			redirect('MyCart');
	}

	public function checkout(){
			$data['carts']="";
			if(isset($_SESSION['unq_id'])){
				$unq_id = $this->session->userdata('unq_id');
				$data['carts']= $this->Home_model->getCarts($unq_id);
				$data['total']= $this->Home_model->getGrandTotal($unq_id);

				$this->load->view('header');
				$this->load->view('checkout',$data);
				$this->load->view('footer');
				
			}else{
				redirect('/');
			}
			
			
	}

	public function buy(){
		if(isset($_SESSION['unq_id'])){
				$unq_id = $this->session->userdata('unq_id');
				$data= array(
					'unq_id' => $unq_id,
					'name' => $this->input->post('firstName').' '.$this->input->post('lastName'),
					'email' => $this->input->post('email'),
					'phone' => $this->input->post('phone'),
					'address1' => $this->input->post('address'),
					'address2' => $this->input->post('address2'),
					'country' => $this->input->post('country'),
					'state' => $this->input->post('state'),
					'zip' => $this->input->post('zip'),
					'total_price' => $this->input->post('hGrandTotal'),
				);

				$created= $this->db->insert('payments',$data);
				
				if($created){
					//Set variables for paypal form
			        $returnURL = base_url().'paypal/success'; //payment success url
			        $cancelURL = base_url().'paypal/cancel'; //payment cancel url
			        $notifyURL = base_url().'paypal/ipn'; //ipn url
			      
			       
			        $userID = $this->session->userdata('unq_id'); //current user id
			        $logo = base_url().'assets/images/5.png';
			        
			        $this->paypal_lib->add_field('return', $returnURL);
			        $this->paypal_lib->add_field('cancel_return', $cancelURL);
			        $this->paypal_lib->add_field('notify_url', $notifyURL);
			        $this->paypal_lib->add_field('custom', $userID);
			        //$this->paypal_lib->add_field('item_number',  '1');
			        $this->paypal_lib->add_field('amount',  $data['total_price']);        
			        $this->paypal_lib->image($logo);
			        
			        $this->paypal_lib->paypal_auto_form();
				}
			}else{
				redirect('/');
			}
        
    }

    	public function removeProduct($id){
			$data= $this->Home_model->removeProduct($id);
			redirect('MyCart');
		}


}
?>