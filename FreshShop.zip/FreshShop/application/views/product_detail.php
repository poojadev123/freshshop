<!-- Start All Title Box -->
    <div class="all-title-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Shop Detail</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Shop</a></li>
                        <li class="breadcrumb-item active">Shop Detail </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Shop Detail  -->
    <div class="shop-detail-box-main">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-5 col-md-6">
                    <div id="carousel-example-1" class="single-product-slider carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active"> <img class="d-block w-100" src="<?php echo base_url().$product->pimage;?>" alt="First slide"> </div>
                            <div class="carousel-item"> <img class="d-block w-100" src="<?php echo base_url().$product->pimage;?>" alt="Second slide"> </div>
                            <div class="carousel-item"> <img class="d-block w-100" src="<?php echo base_url().$product->pimage;?>" alt="Third slide"> </div>
                        </div>
                        <a class="carousel-control-prev" href="#carousel-example-1" role="button" data-slide="prev"> 
						<i class="fa fa-angle-left" aria-hidden="true"></i>
						<span class="sr-only">Previous</span> 
					</a>
                        <a class="carousel-control-next" href="#carousel-example-1" role="button" data-slide="next"> 
						<i class="fa fa-angle-right" aria-hidden="true"></i> 
						<span class="sr-only">Next</span> 
					</a>
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example-1" data-slide-to="0" class="active">
                                <img class="d-block w-100 img-fluid" src="<?php echo base_url().$product->pimage;?>" alt="" />
                            </li>
                            
                        </ol>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7 col-md-6">
                    <div class="single-product-details">
                        <h2><?php echo $product->title;?></h2>
                        <h5> <del>$ 60.00</del> $<?php echo $product->price;?></h5>
						<h4>Short Description:</h4>
						<p><?php echo $product->pdescription;?> </p>
						

						<div class="price-box-bar">
							<div class="cart-and-bay-btn">
								<a class="btn hvr-hover" data-fancybox-close="" onclick="addToCart('<?php echo $product->product_id?>')">Add to cart</a>
							</div>
						</div>

                    </div>
                </div>
            </div>
			
			<div class="row my-5">
				<div class="card card-outline-secondary my-4">
					<div class="card-header">
						<h2>Product Reviews</h2>
					</div>
					<div class="card-body">
						<div class="media mb-3">
							<div class="mr-2"> 
								<img class="rounded-circle border p-1" src="<?php echo base_url().$product->pimage;?>" alt="Generic placeholder image">
							</div>
							<div class="media-body">
								<p><?php echo $product->title;?></p>
								<small class="text-muted">Posted by Anonymous on <?php echo $product->created_at?></small>
							</div>
						</div>
						<hr>
						
						<a href="#" class="btn hvr-hover">Leave a Review</a>
					</div>
				  </div>
			</div>

        </div>
    </div>
    <!-- End Cart -->

    <script type="text/javascript">
function addToCart(id){
    var url = "<?php echo base_url().'addToCart'; ?>";
     $.ajax({
          type:'POST',
          url:url,
          method:"POST",    
          data:{'pid':id,'qty':1},
          dataType:'json',
          success:function(data){
              if(data['status'] == 1){
                window.location.href='<?php echo base_url()."MyCart"?>';
              }else{
                console.log("not success");
              } 
                
            }
        });
}

</script>
