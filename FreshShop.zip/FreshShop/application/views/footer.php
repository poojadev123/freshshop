
    <!-- Start copyright  -->
    <div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2018</p>
    </div>
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="<?php echo base_url(); ?>assets/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.superslides.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap-select.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/inewsticker.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootsnav.js."></script>
    <script src="<?php echo base_url(); ?>assets/js/images-loded.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/isotope.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/baguetteBox.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/form-validator.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/contact-form-script.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
</body>

</html>