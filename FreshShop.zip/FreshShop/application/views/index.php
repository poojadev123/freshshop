

    <!-- Start Categories  -->
    <div class="categories-shop">
        <div class="container">
            <div class="row">
                <?php
                    if(!empty($catgories)){
                        foreach($catgories as $category){
                        ?>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="shop-cat-box">
                                <img class="img-fluid" src="<?php echo base_url().$category->image; ?>" alt="" />
                                <a class="btn hvr-hover" href="<?php echo site_url().'category/'.$category->id; ?>"><?php echo $category->category; ?></a>
                            </div>
                        </div>
                <?php
                        }
                    }
                ?>
                <!-- <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="shop-cat-box">
                        <img class="img-fluid" src="<?php echo base_url(); ?>assets/images/categories_img_01.jpg" alt="" />
                        <a class="btn hvr-hover" href="#">Lorem ipsum dolor</a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="shop-cat-box">
                        <img class="img-fluid" src="<?php echo base_url(); ?>assets/images/categories_img_02.jpg" alt="" />
                        <a class="btn hvr-hover" href="#">Lorem ipsum dolor</a>
                    </div>
                </div> -->
                
            </div>
        </div>
    </div>
    <!-- End Categories -->
