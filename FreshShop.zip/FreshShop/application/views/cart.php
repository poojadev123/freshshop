
    <!-- Start All Title Box -->
    <div class="all-title-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Cart</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Shop</a></li>
                        <li class="breadcrumb-item active">Cart</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Cart  -->
    <div class="cart-box-main">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-main table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Images</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    if(!empty($carts)){
                                        foreach($carts as $cart){
                                ?>
                                <tr>
                                    <td class="thumbnail-img">
                                        <a href="#">
									<img class="img-fluid" src="<?php echo base_url().$cart->pimage ?>" alt="" />
								</a>
                                    </td>
                                    <td class="name-pr">
                                        <a href="#">
									<?php echo $cart->title ?>
								</a>
                                    </td>
                                    <td class="price-pr">
                                        <p>$ <?php echo $cart->price ?></p>
                                    </td>
                                    <td class="quantity-box"><input type="number" size="4" value="<?php echo $cart->qty?>" min="1" step="1" class="c-input-text qty text" onchange="updateQty('<?php echo $cart->product_id?>','<?php echo $cart->cart_id?>',this.value,'<?php echo $cart->price?>')"></td>
                                    <td class="total-pr">
                                        <p id="tprice<?php echo $cart->cart_id?>">$ <?php echo $cart->total_price ?></p>
                                        <input type="hidden" class="htPrice" id="htPriceId<?php echo $cart->cart_id?>" value="<?php echo $cart->total_price ?>">
                                    </td>
                                    <td class="remove-pr">
                                        <a href="<?php echo base_url().'remove/'.$cart->cart_id?>">
									<i class="fas fa-times"></i>
								</a>
                                    </td>
                                </tr>
                                <?php }} ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row my-5">
                <div class="col-lg-6 col-sm-6">
                    
                </div>
                <div class="col-lg-6 col-sm-6">
                    <div class="update-box">
                        <form action="<?php echo base_url().'Home/clearCart'; ?>" action="post">
                            <input value="Clear Cart" type="submit">
                        </form>
                    </div>
                </div>
            </div>

            <div class="row my-5">
                <div class="col-lg-8 col-sm-12"></div>
                <div class="col-lg-4 col-sm-12">
                    <div class="order-box">
                        <h3>Order summary</h3>
                        
                        <div class="d-flex gr-total">
                            <h5>Grand Total</h5>
                            <div class="ml-auto h5" id="GrandTotal"> $ <?php echo (!empty($total) ? $total->tp: "");?> </div>
                        </div>
                        <hr> </div>
                </div>
                <div class="col-12 d-flex shopping-box">
                    <a href="<?php echo base_url().'checkout';?>" class="ml-auto btn hvr-hover">Checkout</a> 

                </div>
            </div>

        </div>
    </div>
    <!-- End Cart -->
<script type="text/javascript">
function updateQty(pid,id,qty,price){
    var url = "<?php echo base_url().'addToCart'; ?>";
     $.ajax({
          type:'POST',
          url:url,
          method:"POST",    
          data:{'pid':pid,'qty':qty},
          dataType:'json',
          success:function(data){
              if(data['status'] == 1){
                var tprice= qty*price;
                $("#tprice"+id).html("$ "+tprice);
                $("#htPriceId"+id).val(tprice);
               // window.location.href='<?php echo base_url()."MyCart"?>';
               var total = 0;
                $('.htPrice').each(function(){
                    total += parseFloat(this.value);
                });
                $('#GrandTotal').html("$ "+total);
              }else{
                console.log("not success");
              } 
                
            }
        });
}

</script>