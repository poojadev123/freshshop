# paypal-library-for-codeigniter
This repository contains PayPal library with the config file for helping to integrate PayPal Payment Gateway in Codeigniter.

#Usage:
Paypal_lib library has a dependency of a config file called paypallib_config.php. paypal_lib.php file will be placed in the "application/libraries/" directory and paypallib_config.php file will be placed in the "application/config/" directory.
